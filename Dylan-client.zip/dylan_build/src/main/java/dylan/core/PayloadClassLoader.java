/*
 * Decompiled with CFR 0.152.
 */
package dylan.core;

import java.io.IOException;
import java.io.InputStream;
import dylan.core.AesCrypto;

final class PayloadClassLoader
extends ClassLoader {
    private final ClassLoader jarResourceLoader;
    private final byte[] key;

    PayloadClassLoader(ClassLoader parent, ClassLoader jarResourceLoader, byte[] key) {
        super(parent);
        this.jarResourceLoader = jarResourceLoader;
        this.key = key;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        Class<?> clazz;
        block9: {
            String resourcePath = name.replace('.', '/') + ".enc";
            InputStream in = this.jarResourceLoader.getResourceAsStream(resourcePath);
            try {
                if (in == null) {
                    throw new ClassNotFoundException(name);
                }
                byte[] encrypted = in.readAllBytes();
                byte[] decrypted = AesCrypto.decrypt(encrypted, this.key);
                clazz = this.defineClass(name, decrypted, 0, decrypted.length);
                if (in == null) break block9;
            }
            catch (Throwable throwable) {
                try {
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException e) {
                    throw new ClassNotFoundException(name, e);
                }
            }
            in.close();
        }
        return clazz;
    }
}

