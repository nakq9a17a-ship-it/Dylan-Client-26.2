/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package dylan.settings.impl;

import lombok.Generated;
import dylan.Dylan;
import dylan.events.impl.SettingChangeEvent;
import dylan.settings.Setting;

public class ImageSetting
extends Setting {
    private String value;
    private final String defaultValue;

    public ImageSetting(String name, String description, String value) {
        super(name, name, description, new Setting.Visibility());
        this.value = value;
        this.defaultValue = value;
    }

    public ImageSetting(String name, String tag, String description, String value) {
        super(name, tag, description, new Setting.Visibility());
        this.value = value;
        this.defaultValue = value;
    }

    public ImageSetting(String name, String description, Setting.Visibility visibility, String value) {
        super(name, name, description, visibility);
        this.value = value;
        this.defaultValue = value;
    }

    public ImageSetting(String name, String tag, String description, Setting.Visibility visibility, String value) {
        super(name, tag, description, visibility);
        this.value = value;
        this.defaultValue = value;
    }

    public void resetValue() {
        this.setValue(this.defaultValue);
    }

    public void setValue(String value) {
        this.value = value;
        if (Dylan.IMAGE_MANAGER != null) {
            Dylan.IMAGE_MANAGER.setCurrentActiveImage(value);
        }
        Dylan.EVENT_HANDLER.post(new SettingChangeEvent(this));
    }

    @Generated
    public String getValue() {
        return this.value;
    }

    @Generated
    public String getDefaultValue() {
        return this.defaultValue;
    }
}

