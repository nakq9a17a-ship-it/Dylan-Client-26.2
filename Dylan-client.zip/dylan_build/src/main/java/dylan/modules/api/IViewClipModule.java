/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IViewClipModule {
    public boolean isToggled();

    public boolean isExtend();

    public float getDistanceValue();
}

