/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IPatchModule {
    public boolean isToggled();

    public boolean isGrimAttackVelocity();
}

