/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IHoleSnapModule {
    public boolean isToggled();

    public boolean isStepEnabled();
}

