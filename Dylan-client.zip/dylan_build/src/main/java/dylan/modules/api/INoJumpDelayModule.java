/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface INoJumpDelayModule {
    public boolean isToggled();

    public int getTicksValue();
}

