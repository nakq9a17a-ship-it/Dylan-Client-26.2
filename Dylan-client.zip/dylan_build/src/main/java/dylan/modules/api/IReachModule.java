/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IReachModule {
    public boolean isToggled();

    public double getAmountValue();
}

