/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IFullBrightModule {
    public boolean isToggled();

    public String getModeValue();
}

