/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface ISpeedModule {
    public boolean isToggled();

    public String getModeValue();

    public float getVanillaSpeedValue();
}

