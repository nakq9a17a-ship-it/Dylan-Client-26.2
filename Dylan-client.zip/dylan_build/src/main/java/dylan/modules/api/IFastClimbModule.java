/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IFastClimbModule {
    public boolean isToggled();

    public float getSpeedValue();
}

