/*
 * Decompiled with CFR 0.152.
 */
package dylan.modules.api;

public interface IAutoWalkModule {
    public boolean isToggled();

    public boolean isBackward();
}

