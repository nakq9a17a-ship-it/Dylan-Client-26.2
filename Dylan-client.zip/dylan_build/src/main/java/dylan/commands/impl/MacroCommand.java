/*
 * Decompiled with CFR 0.152.
 */
package dylan.commands.impl;

import java.util.Arrays;
import java.util.List;
import dylan.Dylan;
import dylan.commands.Command;
import dylan.commands.RegisterCommand;
import dylan.utils.chat.ChatUtils;
import dylan.utils.input.KeyboardUtils;

@RegisterCommand(name="macro", tag="Macro", description="Allows you to manage the client's macro system.", syntax="add <[key]> <[message]> | remove <[key]> | <clear|list>")
public class MacroCommand
extends Command {
    @Override
    public List<String> getSuggestions(String[] args) {
        if (args.length == 0) {
            return List.of("add", "remove", "clear", "list");
        }
        return List.of();
    }

    @Override
    public void execute(String[] args) {
        if (args.length >= 3) {
            if (args[0].equalsIgnoreCase("add")) {
                int key = KeyboardUtils.getKeyNumber(args[1]);
                if (key == 0) {
                    Dylan.CHAT_MANAGER.tagged("The keybind specified is not valid.", this.getTag());
                    return;
                }
                StringBuilder builder = new StringBuilder();
                String[] array = Arrays.copyOfRange(args, 2, args.length);
                int index = 0;
                for (String str : array) {
                    builder.append(str).append(++index == array.length ? "" : " ");
                }
                Dylan.MACRO_MANAGER.add(builder.toString(), key);
                Dylan.CHAT_MANAGER.tagged("Successfully added " + String.valueOf(ChatUtils.getPrimary()) + String.valueOf(builder) + String.valueOf(ChatUtils.getSecondary()) + " as a macro, bound to the " + String.valueOf(ChatUtils.getPrimary()) + KeyboardUtils.getKeyName(key) + String.valueOf(ChatUtils.getSecondary()) + " key.", this.getTag(), "command-" + this.getName());
            } else {
                this.messageSyntax();
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("remove")) {
                int key = KeyboardUtils.getKeyNumber(args[1]);
                if (key == 0) {
                    Dylan.CHAT_MANAGER.tagged("The keybind specified is not valid.", this.getTag());
                    return;
                }
                if (!Dylan.MACRO_MANAGER.containsValue(key)) {
                    Dylan.CHAT_MANAGER.tagged("There is no macro with the " + String.valueOf(ChatUtils.getPrimary()) + KeyboardUtils.getKeyName(key) + String.valueOf(ChatUtils.getSecondary()) + " key.", this.getTag(), "command-" + this.getName());
                } else {
                    Dylan.CHAT_MANAGER.tagged("Successfully removed the " + String.valueOf(ChatUtils.getPrimary()) + Dylan.MACRO_MANAGER.getKey(key) + String.valueOf(ChatUtils.getSecondary()) + " macro.", this.getTag(), "command-" + this.getName());
                    Dylan.MACRO_MANAGER.remove(Dylan.MACRO_MANAGER.getKey(key));
                }
            } else {
                this.messageSyntax();
            }
        } else if (args.length == 1) {
            if (args[0].equalsIgnoreCase("clear")) {
                Dylan.MACRO_MANAGER.clear();
                Dylan.CHAT_MANAGER.tagged("Successfully removed all macros.", this.getTag(), "command-" + this.getName());
            } else if (args[0].equalsIgnoreCase("list")) {
                if (Dylan.MACRO_MANAGER.getMacros().isEmpty()) {
                    Dylan.CHAT_MANAGER.tagged("There are currently no macros added.", this.getTag(), "command-" + this.getName() + "-list");
                } else {
                    StringBuilder builder = new StringBuilder();
                    int index = 0;
                    for (String message : Dylan.MACRO_MANAGER.getMacros().keySet()) {
                        int key = Dylan.MACRO_MANAGER.getValue(message);
                        builder.append(ChatUtils.getSecondary()).append(message).append(ChatUtils.getPrimary()).append(" [").append(ChatUtils.getSecondary()).append(KeyboardUtils.getKeyName(key)).append(ChatUtils.getPrimary()).append("]").append(ChatUtils.getSecondary()).append(++index == Dylan.MACRO_MANAGER.getMacros().size() ? "" : ", ");
                    }
                    Dylan.CHAT_MANAGER.message("Macros " + String.valueOf(ChatUtils.getPrimary()) + "[" + String.valueOf(ChatUtils.getSecondary()) + Dylan.MACRO_MANAGER.getMacros().size() + String.valueOf(ChatUtils.getPrimary()) + "]: " + String.valueOf(ChatUtils.getSecondary()) + String.valueOf(builder), "command-" + this.getName() + "-list");
                }
            } else {
                this.messageSyntax();
            }
        } else {
            this.messageSyntax();
        }
    }
}

