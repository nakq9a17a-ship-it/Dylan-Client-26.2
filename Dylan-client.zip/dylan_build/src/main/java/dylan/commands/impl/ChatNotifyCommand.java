/*
 * Decompiled with CFR 0.152.
 */
package dylan.commands.impl;

import java.util.ArrayList;
import java.util.List;
import dylan.Dylan;
import dylan.commands.Command;
import dylan.commands.RegisterCommand;
import dylan.modules.Module;
import dylan.utils.chat.ChatUtils;

@RegisterCommand(name="chatnotify", tag="ChatNotify", description="Manages the toggle notification status of the client's modules.", syntax="<true|false|list|reset> | <[module]> <true|false|reset>")
public class ChatNotifyCommand
extends Command {
    @Override
    public List<String> getSuggestions(String[] args) {
        if (args.length == 0) {
            ArrayList<String> names = new ArrayList<String>(this.moduleNames());
            names.add("true");
            names.add("false");
            names.add("list");
            names.add("reset");
            return names;
        }
        if (args.length == 1 && Dylan.MODULE_MANAGER.getModule(args[0]) != null) {
            return List.of("true", "false", "reset");
        }
        return List.of();
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 2) {
            Module module = Dylan.MODULE_MANAGER.getModule(args[0]);
            if (module == null) {
                Dylan.CHAT_MANAGER.tagged("Could not find the module specified.", this.getTag(), this.getName());
                return;
            }
            switch (args[1]) {
                case "true": {
                    module.chatNotify.setValue(true);
                    Dylan.CHAT_MANAGER.tagged("Successfully set the module's notification status to " + String.valueOf(ChatUtils.getPrimary()) + "true" + String.valueOf(ChatUtils.getSecondary()) + ".", this.getTag(), this.getName());
                    break;
                }
                case "false": {
                    module.chatNotify.setValue(false);
                    Dylan.CHAT_MANAGER.tagged("Successfully set the module's notification status to " + String.valueOf(ChatUtils.getPrimary()) + "false" + String.valueOf(ChatUtils.getSecondary()) + ".", this.getTag(), this.getName());
                    break;
                }
                case "reset": {
                    module.chatNotify.setValue(module.chatNotify.getDefaultValue());
                    Dylan.CHAT_MANAGER.tagged("Successfully set the module's notification status to it's default value.", this.getTag(), this.getName());
                    break;
                }
                default: {
                    this.messageSyntax();
                    break;
                }
            }
        } else if (args.length == 1) {
            switch (args[0]) {
                case "true": {
                    for (Module module : Dylan.MODULE_MANAGER.getModules()) {
                        module.chatNotify.setValue(true);
                    }
                    Dylan.CHAT_MANAGER.tagged("Successfully set every module's notification status to " + String.valueOf(ChatUtils.getPrimary()) + "true" + String.valueOf(ChatUtils.getSecondary()) + ".", this.getTag(), this.getName());
                    break;
                }
                case "false": {
                    for (Module module : Dylan.MODULE_MANAGER.getModules()) {
                        module.chatNotify.setValue(false);
                    }
                    Dylan.CHAT_MANAGER.tagged("Successfully set every module's notification status to " + String.valueOf(ChatUtils.getPrimary()) + "false" + String.valueOf(ChatUtils.getSecondary()) + ".", this.getTag(), this.getName());
                    break;
                }
                case "list": {
                    ArrayList<Module> notifiableModules = new ArrayList<Module>(Dylan.MODULE_MANAGER.getModules().stream().filter(m -> m.chatNotify.getValue()).toList());
                    if (notifiableModules.isEmpty()) {
                        Dylan.CHAT_MANAGER.tagged("There are currently no modules with their notification status set to " + String.valueOf(ChatUtils.getPrimary()) + "true" + String.valueOf(ChatUtils.getSecondary()) + ".", this.getTag(), this.getName() + "-list");
                        break;
                    }
                    StringBuilder modulesString = new StringBuilder();
                    int index = 0;
                    for (Module module : notifiableModules) {
                        modulesString.append(ChatUtils.getSecondary()).append(module.getName()).append(index + 1 == notifiableModules.size() ? "" : ", ");
                        ++index;
                    }
                    Dylan.CHAT_MANAGER.message(String.valueOf(ChatUtils.getSecondary()) + "Notifiable Modules " + String.valueOf(ChatUtils.getPrimary()) + "[" + String.valueOf(ChatUtils.getSecondary()) + notifiableModules.size() + String.valueOf(ChatUtils.getPrimary()) + "]: " + String.valueOf(ChatUtils.getSecondary()) + String.valueOf(modulesString), this.getName() + "-list");
                    break;
                }
                case "reset": {
                    for (Module module : Dylan.MODULE_MANAGER.getModules()) {
                        module.chatNotify.setValue(module.chatNotify.getDefaultValue());
                    }
                    Dylan.CHAT_MANAGER.tagged("Successfully set every module's notification status to it's default value.", this.getTag(), this.getName());
                    break;
                }
                default: {
                    this.messageSyntax();
                }
            }
        } else {
            this.messageSyntax();
        }
    }
}

