/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Util
 */
package dylan.commands.impl;

import java.io.File;
import net.minecraft.util.Util;
import dylan.Dylan;
import dylan.commands.Command;
import dylan.commands.RegisterCommand;

@RegisterCommand(name="folder", description="Opens the clients folder.")
public class FolderCommand
extends Command {
    @Override
    public void execute(String[] args) {
        File folder = new File("Dylan");
        if (folder.exists()) {
            Util.getPlatform().openFile(folder);
        } else {
            Dylan.CHAT_MANAGER.info("Could not find the client's configuration folder.");
        }
    }
}

