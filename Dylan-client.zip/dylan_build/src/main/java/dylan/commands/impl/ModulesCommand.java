/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.ChatFormatting
 */
package dylan.commands.impl;

import java.util.List;
import net.minecraft.ChatFormatting;
import dylan.Dylan;
import dylan.commands.Command;
import dylan.commands.RegisterCommand;
import dylan.modules.Module;
import dylan.utils.chat.ChatUtils;

@RegisterCommand(name="modules", tag="Modules", description="Shows you a list of all of the client's modules and their toggle status.", aliases={"mods"})
public class ModulesCommand
extends Command {
    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            List<Module> modules = Dylan.MODULE_MANAGER.getModules();
            if (modules.isEmpty()) {
                Dylan.CHAT_MANAGER.tagged("There are currently no registered modules.", this.getTag(), this.getName());
            } else {
                StringBuilder builder = new StringBuilder();
                int index = 0;
                for (Module module : modules) {
                    builder.append(ChatUtils.getSecondary()).append(module.getName()).append(ChatUtils.getPrimary()).append(" [").append(module.isToggled() ? String.valueOf(ChatFormatting.GREEN) + "ON" : String.valueOf(ChatFormatting.RED) + "OFF").append(ChatUtils.getPrimary()).append("]").append(++index == modules.size() ? "" : ", ");
                }
                Dylan.CHAT_MANAGER.message("Modules " + String.valueOf(ChatUtils.getPrimary()) + "[" + String.valueOf(ChatUtils.getSecondary()) + modules.size() + String.valueOf(ChatUtils.getPrimary()) + "]: " + String.valueOf(ChatUtils.getSecondary()) + String.valueOf(builder), this.getName());
            }
        } else {
            this.messageSyntax();
        }
    }
}

