/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.player.LocalPlayer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dylan.mixins;

import net.minecraft.client.player.LocalPlayer;
import dylan.Dylan;
import dylan.mixins.accessors.EntityAccessor;
import dylan.modules.impl.player.RotationLockModule;
import dylan.utils.IMinecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LocalPlayer.class})
public abstract class LocalPlayerMixin
implements IMinecraft {
    @Inject(method={"getViewYRot"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$unlockViewYaw(float partialTick, CallbackInfoReturnable<Float> info) {
        if (((LocalPlayer)this).isPassenger()) {
            return;
        }
        RotationLockModule lock = Dylan.MODULE_MANAGER.getModule(RotationLockModule.class);
        if (lock.isToggled() && lock.custom.getValue() && (lock.mode.getValue().equals("Yaw") || lock.mode.getValue().equals("Both"))) {
            info.setReturnValue((Object)Float.valueOf(((EntityAccessor)((Object)this)).getRawYRot()));
        }
    }

    @Inject(method={"getViewXRot"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$unlockViewPitch(float partialTick, CallbackInfoReturnable<Float> info) {
        RotationLockModule lock = Dylan.MODULE_MANAGER.getModule(RotationLockModule.class);
        if (lock.isToggled() && lock.custom.getValue() && (lock.mode.getValue().equals("Pitch") || lock.mode.getValue().equals("Both"))) {
            info.setReturnValue((Object)Float.valueOf(((EntityAccessor)((Object)this)).getRawXRot()));
        }
    }
}

