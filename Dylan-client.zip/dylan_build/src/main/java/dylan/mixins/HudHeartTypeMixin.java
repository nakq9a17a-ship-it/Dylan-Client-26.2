/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dylan.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dylan.Dylan;
import dylan.modules.impl.visuals.NoRenderModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets={"net.minecraft.client.gui.Hud$HeartType"})
public class HudHeartTypeMixin {
    @ModifyExpressionValue(method={"forPlayer"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/player/Player;hasEffect(Lnet/minecraft/core/Holder;)Z", ordinal=1)})
    private static boolean dylan$hideWitherHeart(boolean original) {
        NoRenderModule noRender;
        if (original && Dylan.MODULE_MANAGER != null && (noRender = Dylan.MODULE_MANAGER.getModule(NoRenderModule.class)).isToggled() && noRender.wither.getValue()) {
            return false;
        }
        return original;
    }
}

