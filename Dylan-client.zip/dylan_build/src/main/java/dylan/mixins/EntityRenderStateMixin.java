/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.state.EntityRenderState
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package dylan.mixins;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import dylan.utils.graphics.Glint;
import dylan.utils.mixins.IChamsCapture;
import dylan.utils.mixins.ISelfState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={EntityRenderState.class})
public class EntityRenderStateMixin
implements IChamsCapture,
ISelfState {
    @Unique
    private boolean chamsFill = false;
    @Unique
    private int chamsFillColor = 0;
    @Unique
    private boolean chamsOutline = false;
    @Unique
    private int chamsOutlineColor = 0;
    @Unique
    private boolean chamsShine = false;
    @Unique
    private boolean chamsGlint = false;
    @Unique
    private int chamsGlintColor = -1;
    @Unique
    private Glint.GlintParams chamsGlintParams = Glint.ENTITY;
    @Unique
    private boolean chamsSuppressReal = false;
    @Unique
    private float chamsRealAlpha = 1.0f;
    @Unique
    private float chamsYOffset = 0.0f;
    @Unique
    private boolean isSelf = false;

    @Override
    public float dylan$chamsYOffset() {
        return this.chamsYOffset;
    }

    @Override
    public void dylan$setChamsYOffset(float offset) {
        this.chamsYOffset = offset;
    }

    @Override
    public boolean dylan$isSelf() {
        return this.isSelf;
    }

    @Override
    public void dylan$setSelf(boolean self) {
        this.isSelf = self;
    }

    @Override
    public boolean dylan$chamsFill() {
        return this.chamsFill;
    }

    @Override
    public int dylan$chamsFillColor() {
        return this.chamsFillColor;
    }

    @Override
    public boolean dylan$chamsOutline() {
        return this.chamsOutline;
    }

    @Override
    public int dylan$chamsOutlineColor() {
        return this.chamsOutlineColor;
    }

    @Override
    public boolean dylan$chamsShine() {
        return this.chamsShine;
    }

    @Override
    public boolean dylan$chamsGlint() {
        return this.chamsGlint;
    }

    @Override
    public int dylan$chamsGlintColor() {
        return this.chamsGlintColor;
    }

    @Override
    public Glint.GlintParams dylan$chamsGlintParams() {
        return this.chamsGlintParams;
    }

    @Override
    public boolean dylan$chamsSuppressReal() {
        return this.chamsSuppressReal;
    }

    @Override
    public float dylan$chamsRealAlpha() {
        return this.chamsRealAlpha;
    }

    @Override
    public void dylan$setChamsRealAlpha(float alpha) {
        this.chamsRealAlpha = alpha;
    }

    @Override
    public void dylan$setChamsGlint(boolean glint, int glintColor) {
        this.chamsGlint = glint;
        this.chamsGlintColor = glintColor;
        this.chamsGlintParams = Glint.ENTITY;
    }

    @Override
    public void dylan$setChamsGlint(boolean glint, int glintColor, Glint.GlintParams params) {
        this.chamsGlint = glint;
        this.chamsGlintColor = glintColor;
        this.chamsGlintParams = params != null ? params : Glint.ENTITY;
    }

    @Override
    public void dylan$setChams(boolean fill, int fillColor, boolean outline, int outlineColor, boolean shine) {
        this.dylan$setChams(fill, fillColor, outline, outlineColor, shine, false);
    }

    @Override
    public void dylan$setChams(boolean fill, int fillColor, boolean outline, int outlineColor, boolean shine, boolean suppressReal) {
        this.chamsFill = fill;
        this.chamsFillColor = fillColor;
        this.chamsOutline = outline;
        this.chamsOutlineColor = outlineColor;
        this.chamsShine = shine;
        this.chamsSuppressReal = suppressReal;
        this.chamsRealAlpha = 1.0f;
        this.chamsGlint = false;
        this.chamsGlintColor = -1;
        this.chamsGlintParams = Glint.ENTITY;
    }
}

