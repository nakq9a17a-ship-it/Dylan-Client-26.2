/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.client.player.RemotePlayer
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityFluidInteraction
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.material.Fluid
 *  net.minecraft.world.phys.Vec3
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dylan.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityFluidInteraction;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.phys.Vec3;
import dylan.Dylan;
import dylan.events.impl.ChangePitchEvent;
import dylan.events.impl.ChangeYawEvent;
import dylan.events.impl.UpdateVelocityEvent;
import dylan.managers.RotationManager;
import dylan.modules.api.IFreecamModule;
import dylan.modules.impl.combat.AutoMaceModule;
import dylan.modules.impl.miscellaneous.FakePlayerModule;
import dylan.modules.impl.movement.ElytraFlyModule;
import dylan.modules.impl.movement.NoSlowModule;
import dylan.modules.impl.movement.VelocityModule;
import dylan.modules.impl.player.RotationLockModule;
import dylan.modules.impl.visuals.LogoutSpotModule;
import dylan.modules.impl.visuals.PopChamsModule;
import dylan.utils.IMinecraft;
import dylan.utils.minecraft.EntityUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={Entity.class})
public abstract class EntityMixin
implements IMinecraft {
    @Shadow
    private float yRot;
    @Shadow
    private float xRot;

    @Inject(method={"tick"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$cancelGhostTick(CallbackInfo ci) {
        EntityMixin entityMixin = this;
        if (entityMixin instanceof RemotePlayer) {
            LogoutSpotModule logoutSpot;
            PopChamsModule popChams;
            RemotePlayer ghost = (RemotePlayer)entityMixin;
            PopChamsModule popChamsModule = popChams = Dylan.MODULE_MANAGER != null ? Dylan.MODULE_MANAGER.getModule(PopChamsModule.class) : null;
            if (popChams != null && popChams.isGhost((Entity)ghost)) {
                ci.cancel();
                return;
            }
            LogoutSpotModule logoutSpotModule = logoutSpot = Dylan.MODULE_MANAGER != null ? Dylan.MODULE_MANAGER.getModule(LogoutSpotModule.class) : null;
            if (logoutSpot != null && logoutSpot.isGhost((Entity)ghost)) {
                ci.cancel();
            }
        }
    }

    @Inject(method={"turn"}, at={@At(value="HEAD")}, cancellable=true)
    public void onTurn(double cursorDeltaYaw, double cursorDeltaPitch, CallbackInfo ci) {
        if (this == EntityMixin.mc.player && Dylan.MODULE_MANAGER != null) {
            IFreecamModule freecam = (IFreecamModule)((Object)Dylan.MODULE_MANAGER.getModule("Freecam"));
            if (freecam != null && freecam.isToggled() && !freecam.isRotate()) {
                freecam.onMouseTurn(cursorDeltaYaw, cursorDeltaPitch);
                ci.cancel();
                return;
            }
            ElytraFlyModule elytraFly = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class);
            if (elytraFly != null && elytraFly.isFreeLookActive()) {
                elytraFly.onMouseTurn(cursorDeltaYaw, cursorDeltaPitch);
                ci.cancel();
                return;
            }
            AutoMaceModule autoMace = Dylan.MODULE_MANAGER.getModule(AutoMaceModule.class);
            if (autoMace != null && autoMace.isFreeLookActive()) {
                autoMace.onMouseTurn(cursorDeltaYaw, cursorDeltaPitch);
                ci.cancel();
            }
        }
    }

    @Inject(method={"push(Lnet/minecraft/world/entity/Entity;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void pushAwayFrom(Entity entity, CallbackInfo info) {
        if (this == EntityMixin.mc.player && this.isPhantomEntity(entity) || entity == EntityMixin.mc.player && this.isPhantomEntity((Entity)this)) {
            info.cancel();
            return;
        }
        if (this == EntityMixin.mc.player && Dylan.MODULE_MANAGER.getModule(VelocityModule.class).isToggled() && Dylan.MODULE_MANAGER.getModule(VelocityModule.class).antiPush.getValue()) {
            info.cancel();
        }
    }

    private boolean isPhantomEntity(Entity entity) {
        if (EntityUtils.isGhost(entity)) {
            return true;
        }
        FakePlayerModule fakePlayer = Dylan.MODULE_MANAGER.getModule(FakePlayerModule.class);
        return fakePlayer != null && entity == fakePlayer.getPlayer();
    }

    @WrapOperation(method={"updateFluidInteraction"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/EntityFluidInteraction;applyCurrentTo(Lnet/minecraft/tags/TagKey;Lnet/minecraft/world/entity/Entity;D)V")})
    private void updateMovementInFluid(EntityFluidInteraction instance, TagKey<Fluid> fluid, Entity entity, double motionScale, Operation<Void> original) {
        if (this == EntityMixin.mc.player && Dylan.MODULE_MANAGER.getModule(VelocityModule.class).isToggled() && Dylan.MODULE_MANAGER.getModule(VelocityModule.class).antiLiquidPush.getValue()) {
            return;
        }
        original.call(new Object[]{instance, fluid, entity, motionScale});
    }

    @Inject(method={"moveRelative"}, at={@At(value="HEAD")}, cancellable=true)
    private void updateVelocity(float speed, Vec3 movementInput, CallbackInfo info) {
        if (this != EntityMixin.mc.player) {
            return;
        }
        UpdateVelocityEvent event = new UpdateVelocityEvent(movementInput, speed);
        Dylan.EVENT_HANDLER.post(event);
        if (event.isCancelled()) {
            info.cancel();
            EntityMixin.mc.player.setDeltaMovement(EntityMixin.mc.player.getDeltaMovement().add(event.getVelocity()));
        }
    }

    @Inject(method={"getYRot()F"}, at={@At(value="HEAD")}, cancellable=true)
    private void getYaw(CallbackInfoReturnable<Float> info) {
        if (RotationManager.swapActive && this == EntityMixin.mc.player) {
            return;
        }
        RotationLockModule lock = Dylan.MODULE_MANAGER.getModule(RotationLockModule.class);
        if (lock.isToggled() && (lock.mode.getValue().equals("Yaw") || lock.mode.getValue().equals("Both")) && this == EntityMixin.mc.player) {
            info.setReturnValue((Object)Float.valueOf(lock.getYawValue(this.yRot)));
        }
    }

    @Inject(method={"getXRot()F"}, at={@At(value="HEAD")}, cancellable=true)
    private void getPitchRaw(CallbackInfoReturnable<Float> info) {
        if (RotationManager.swapActive && this == EntityMixin.mc.player) {
            return;
        }
        RotationLockModule lock = Dylan.MODULE_MANAGER.getModule(RotationLockModule.class);
        if (lock.isToggled() && (lock.mode.getValue().equals("Pitch") || lock.mode.getValue().equals("Both")) && this == EntityMixin.mc.player) {
            info.setReturnValue((Object)Float.valueOf(lock.getPitchValue(this.xRot)));
        }
    }

    @Inject(method={"setYRot"}, at={@At(value="HEAD")}, cancellable=true)
    private void setYaw(float yaw, CallbackInfo info) {
        if (this != EntityMixin.mc.player) {
            return;
        }
        Dylan.EVENT_HANDLER.post(new ChangeYawEvent(yaw));
    }

    @Inject(method={"setXRot"}, at={@At(value="HEAD")}, cancellable=true)
    private void setPitch(float pitch, CallbackInfo info) {
        if (this != EntityMixin.mc.player) {
            return;
        }
        Dylan.EVENT_HANDLER.post(new ChangePitchEvent(pitch));
    }

    @ModifyExpressionValue(method={"getBlockSpeedFactor"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;")})
    private Block getVelocityMultiplier(Block original) {
        if (Dylan.MODULE_MANAGER.getModule(NoSlowModule.class).isToggled() && (original == Blocks.SOUL_SAND && Dylan.MODULE_MANAGER.getModule(NoSlowModule.class).soulSand.getValue() || original == Blocks.HONEY_BLOCK && Dylan.MODULE_MANAGER.getModule(NoSlowModule.class).honeyBlocks.getValue())) {
            return Blocks.STONE;
        }
        return original;
    }

    @ModifyReturnValue(method={"isSprinting()Z"}, at={@At(value="RETURN")})
    private boolean injectIsSprinting(boolean original) {
        if (this != EntityMixin.mc.player || Dylan.MODULE_MANAGER == null) {
            return original;
        }
        ElytraFlyModule ef = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class);
        if (ef != null && ef.isBounceActive() && ef.isGliding()) {
            return true;
        }
        return original;
    }

    @ModifyReturnValue(method={"getPose"}, at={@At(value="RETURN")})
    private Pose injectGetPose(Pose original) {
        if (this != EntityMixin.mc.player || Dylan.MODULE_MANAGER == null) {
            return original;
        }
        ElytraFlyModule ef = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class);
        if (ef != null && ef.isBounceActive() && ef.isGliding()) {
            return Pose.FALL_FLYING;
        }
        return original;
    }
}

