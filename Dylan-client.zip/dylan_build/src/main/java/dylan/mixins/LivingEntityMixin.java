/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.AttributeInstance
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.component.SwingAnimation
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 *  org.jetbrains.annotations.Nullable
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dylan.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import dylan.Dylan;
import dylan.events.impl.ConsumeItemEvent;
import dylan.events.impl.PlayerJumpEvent;
import dylan.managers.RotationManager;
import dylan.mixins.accessors.EntityAccessor;
import dylan.modules.api.IFastClimbModule;
import dylan.modules.api.IHoleSnapModule;
import dylan.modules.api.INoJumpDelayModule;
import dylan.modules.api.ISprintModule;
import dylan.modules.impl.combat.AutoMaceModule;
import dylan.modules.impl.movement.ElytraFlyModule;
import dylan.modules.impl.movement.StepModule;
import dylan.modules.impl.player.SwingModule;
import dylan.utils.IMinecraft;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LivingEntity.class})
public abstract class LivingEntityMixin
extends Entity
implements IMinecraft {
    @Shadow
    @Final
    private static AttributeModifier SPEED_MODIFIER_SPRINTING;
    @Shadow
    private int noJumpDelay;
    @Shadow
    protected ItemStack useItem;
    @Unique
    private float dylan$grimYaw0;
    @Unique
    private boolean dylan$grimSwapped;

    @Shadow
    @Nullable
    public abstract AttributeInstance getAttribute(Holder<Attribute> var1);

    public LivingEntityMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @WrapMethod(method={"maxUpStep"})
    private float getStepHeight(Operation<Float> original) {
        IHoleSnapModule holeSnap;
        IHoleSnapModule iHoleSnapModule = holeSnap = Dylan.MODULE_MANAGER != null ? (IHoleSnapModule)((Object)Dylan.MODULE_MANAGER.getModule("HoleSnap")) : null;
        if (this == LivingEntityMixin.mc.player && Dylan.MODULE_MANAGER != null && (Dylan.MODULE_MANAGER.getModule(StepModule.class).isToggled() && LivingEntityMixin.mc.player.onGround() || holeSnap != null && holeSnap.isToggled() && holeSnap.isStepEnabled())) {
            return Dylan.MODULE_MANAGER.getModule(StepModule.class).height.getValue().floatValue();
        }
        return ((Float)original.call(new Object[0])).floatValue();
    }

    @Inject(method={"aiStep"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/profiling/ProfilerFiller;pop()V", ordinal=2, shift=At.Shift.BEFORE)})
    private void doItemUse(CallbackInfo info) {
        INoJumpDelayModule noJumpDelayModule;
        INoJumpDelayModule iNoJumpDelayModule = noJumpDelayModule = Dylan.MODULE_MANAGER != null ? (INoJumpDelayModule)((Object)Dylan.MODULE_MANAGER.getModule("NoJumpDelay")) : null;
        if (noJumpDelayModule != null && noJumpDelayModule.isToggled() && this.noJumpDelay == 10) {
            this.noJumpDelay = noJumpDelayModule.getTicksValue();
        }
    }

    @Inject(method={"aiStep"}, at={@At(value="RETURN")})
    private void dylan$bounceNoJumpDelay(CallbackInfo ci) {
        if (this != LivingEntityMixin.mc.player || Dylan.MODULE_MANAGER == null) {
            return;
        }
        ElytraFlyModule ef = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class);
        if (ef != null && ef.isBounceActive()) {
            this.noJumpDelay = 0;
        }
    }

    @WrapOperation(method={"getCurrentSwingDuration"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/item/component/SwingAnimation;duration()I")})
    private int getHandSwingDuration(SwingAnimation instance, Operation<Integer> original) {
        int constant = (Integer)original.call(new Object[]{instance});
        if (this != LivingEntityMixin.mc.player) {
            return constant;
        }
        return Dylan.MODULE_MANAGER.getModule(SwingModule.class).isToggled() && Dylan.MODULE_MANAGER.getModule(SwingModule.class).modifySpeed.getValue() && LivingEntityMixin.mc.options.getCameraType().isFirstPerson() ? 21 - Dylan.MODULE_MANAGER.getModule(SwingModule.class).speed.getValue().intValue() : constant;
    }

    @Inject(method={"completeUsingItem"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;", shift=At.Shift.AFTER)})
    private void consumeItem(CallbackInfo ci) {
        if (this == LivingEntityMixin.mc.player) {
            Dylan.EVENT_HANDLER.post(new ConsumeItemEvent(this.useItem));
        }
    }

    @Inject(method={"setSprinting"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/Entity;setSprinting(Z)V", shift=At.Shift.AFTER)}, cancellable=true)
    private void setSprinting$setSprinting(boolean sprinting, CallbackInfo info) {
        if (this == LivingEntityMixin.mc.player) {
            ISprintModule sprint;
            ElytraFlyModule ef;
            ElytraFlyModule elytraFlyModule = ef = Dylan.MODULE_MANAGER != null ? Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class) : null;
            if (ef != null && ef.isToggled() && ef.mode.getValue().equalsIgnoreCase("Bounce")) {
                return;
            }
            ISprintModule iSprintModule = sprint = Dylan.MODULE_MANAGER == null ? null : (ISprintModule)((Object)Dylan.MODULE_MANAGER.getModule("Sprint"));
            if (sprint != null && sprint.isToggled()) {
                AttributeInstance entityAttributeInstance = this.getAttribute((Holder<Attribute>)Attributes.MOVEMENT_SPEED);
                if (entityAttributeInstance != null) {
                    entityAttributeInstance.removeModifier(SPEED_MODIFIER_SPRINTING.id());
                    if (sprint.shouldSprint()) {
                        this.setSharedFlag(3, true);
                        entityAttributeInstance.addTransientModifier(SPEED_MODIFIER_SPRINTING);
                    } else {
                        this.setSharedFlag(3, false);
                    }
                }
                info.cancel();
            }
        }
    }

    @Inject(method={"jumpFromGround"}, at={@At(value="HEAD")})
    private void jump$HEAD(CallbackInfo info) {
        if (this != LivingEntityMixin.mc.player) {
            return;
        }
        Dylan.EVENT_HANDLER.post(new PlayerJumpEvent());
    }

    @Inject(method={"jumpFromGround"}, at={@At(value="RETURN")})
    private void jump$RETURN(CallbackInfo info) {
        if (this != LivingEntityMixin.mc.player) {
            return;
        }
        Dylan.EVENT_HANDLER.post(new PlayerJumpEvent.Post());
    }

    @Inject(method={"onClimbable"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$fastClimbIgnore(CallbackInfoReturnable<Boolean> cir) {
        if (this != LivingEntityMixin.mc.player) {
            return;
        }
        IFastClimbModule fastClimb = (IFastClimbModule)((Object)Dylan.MODULE_MANAGER.getModule("FastClimb"));
        if (fastClimb.isToggled() && fastClimb.getSpeedValue() == 0.0f) {
            cir.setReturnValue((Object)false);
        }
    }

    @ModifyConstant(method={"handleOnClimbable"}, constant={@Constant(floatValue=0.15f)}, require=0)
    private float dylan$fastClimbScale(float constant) {
        return this.dylan$fastClimbFactor(constant);
    }

    @Unique
    private float dylan$fastClimbFactor(float constant) {
        if (this != LivingEntityMixin.mc.player) {
            return constant;
        }
        IFastClimbModule fastClimb = (IFastClimbModule)((Object)Dylan.MODULE_MANAGER.getModule("FastClimb"));
        if (!fastClimb.isToggled()) {
            return constant;
        }
        float factor = fastClimb.getSpeedValue();
        if (factor <= 0.0f || factor >= 1.0f) {
            return constant;
        }
        return constant * factor;
    }

    @Inject(method={"getItemBySlot"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$hideElytraSwap(EquipmentSlot slot, CallbackInfoReturnable<ItemStack> cir) {
        if (slot != EquipmentSlot.CHEST || this != LivingEntityMixin.mc.player || Dylan.MODULE_MANAGER == null) {
            return;
        }
        ItemStack parked = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class).getGrimHiddenElytra();
        if (parked != null) {
            cir.setReturnValue((Object)parked);
        }
    }

    @Inject(method={"isFallFlying"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$pinBounceAndControlRocketGlide(CallbackInfoReturnable<Boolean> cir) {
        AutoMaceModule am;
        if (this != LivingEntityMixin.mc.player || Dylan.MODULE_MANAGER == null) {
            return;
        }
        ElytraFlyModule ef = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class);
        if (ef != null && ef.isToggled()) {
            if (ef.isBounceActive() && ef.isGliding()) {
                cir.setReturnValue((Object)true);
                return;
            }
            if (ef.shouldPinFallFlying()) {
                cir.setReturnValue((Object)true);
                return;
            }
        }
        if ((am = Dylan.MODULE_MANAGER.getModule(AutoMaceModule.class)) != null && am.shouldPinFallFlying()) {
            cir.setReturnValue((Object)true);
        }
    }

    @WrapOperation(method={"updateFallFlyingMovement"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/LivingEntity;getXRot()F")})
    private float wrapFallFlyingPitch(LivingEntity instance, Operation<Float> original) {
        ElytraFlyModule ef;
        if (this == LivingEntityMixin.mc.player && Dylan.MODULE_MANAGER != null && (ef = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class)) != null && ef.isBounceAutoPitch()) {
            return ef.getBouncePitch();
        }
        return ((Float)original.call(new Object[]{instance})).floatValue();
    }

    @WrapOperation(method={"updateFallFlyingMovement"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/LivingEntity;getLookAngle()Lnet/minecraft/world/phys/Vec3;")})
    private Vec3 wrapFallFlyingLookAngle(LivingEntity instance, Operation<Vec3> original) {
        ElytraFlyModule ef;
        if (this == LivingEntityMixin.mc.player && Dylan.MODULE_MANAGER != null && (ef = Dylan.MODULE_MANAGER.getModule(ElytraFlyModule.class)) != null && ef.isBounceAutoPitch()) {
            return Vec3.directionFromRotation((float)ef.getBouncePitch(), (float)instance.getYRot());
        }
        return (Vec3)original.call(new Object[]{instance});
    }

    @Inject(method={"travel"}, at={@At(value="HEAD")})
    private void travel$grimHead(Vec3 movementInput, CallbackInfo info) {
        this.dylan$grimSwapped = false;
        if (this != LivingEntityMixin.mc.player || !this.dylan$shouldSpoofRotation()) {
            return;
        }
        this.dylan$grimYaw0 = ((EntityAccessor)((Object)this)).getRawYRot();
        ((EntityAccessor)((Object)this)).setRawYRot(this.dylan$spoofYaw());
        RotationManager.swapActive = true;
        this.dylan$grimSwapped = true;
    }

    @Inject(method={"travel"}, at={@At(value="RETURN")})
    private void travel$grimReturn(Vec3 movementInput, CallbackInfo info) {
        if (!this.dylan$grimSwapped) {
            return;
        }
        this.dylan$grimSwapped = false;
        RotationManager.swapActive = false;
        ((EntityAccessor)((Object)this)).setRawYRot(this.dylan$grimYaw0);
    }

    @ModifyExpressionValue(method={"jumpFromGround"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/entity/LivingEntity;getYRot()F")})
    private float jumpFromGround$grimYaw(float original) {
        if (this != LivingEntityMixin.mc.player || !this.dylan$shouldSpoofRotation()) {
            return original;
        }
        return this.dylan$spoofYaw();
    }

    @Unique
    private boolean dylan$grimCompensating() {
        if (Dylan.MODULE_MANAGER == null) {
            return false;
        }
        ISprintModule sprint = (ISprintModule)((Object)Dylan.MODULE_MANAGER.getModule("Sprint"));
        return sprint != null && sprint.isGrimCompensating();
    }

    @Unique
    private boolean dylan$shouldSpoofRotation() {
        return this.dylan$grimCompensating();
    }

    @Unique
    private float dylan$spoofYaw() {
        return ((ISprintModule)((Object)Dylan.MODULE_MANAGER.getModule("Sprint"))).getGrimYaw();
    }
}

