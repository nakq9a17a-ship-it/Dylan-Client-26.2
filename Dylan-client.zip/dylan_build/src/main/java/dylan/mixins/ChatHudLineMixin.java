/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.chat.GuiMessage
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package dylan.mixins;

import net.minecraft.client.multiplayer.chat.GuiMessage;
import dylan.utils.mixins.IChatHudLine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={GuiMessage.class})
public class ChatHudLineMixin
implements IChatHudLine {
    @Unique
    private boolean clientMessage = false;
    @Unique
    private String clientIdentifier = "";

    @Override
    public boolean dylan$isClientMessage() {
        return this.clientMessage;
    }

    @Override
    public void dylan$setClientMessage(boolean clientMessage) {
        this.clientMessage = clientMessage;
    }

    @Override
    public String dylan$getClientIdentifier() {
        return this.clientIdentifier;
    }

    @Override
    public void dylan$setClientIdentifier(String clientIdentifier) {
        this.clientIdentifier = clientIdentifier;
    }
}

