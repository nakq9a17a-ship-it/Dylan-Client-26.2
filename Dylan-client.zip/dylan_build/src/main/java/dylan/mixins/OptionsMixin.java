/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.CameraType
 *  net.minecraft.client.Options
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dylan.mixins;

import net.minecraft.client.CameraType;
import net.minecraft.client.Options;
import dylan.Dylan;
import dylan.modules.api.IFreecamModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={Options.class})
public abstract class OptionsMixin {
    @Inject(method={"setCameraType"}, at={@At(value="HEAD")}, cancellable=true)
    private void dylan$blockThirdPersonOnFreecam(CameraType cameraType, CallbackInfo ci) {
        IFreecamModule freecam;
        if (Dylan.MODULE_MANAGER != null && (freecam = (IFreecamModule)((Object)Dylan.MODULE_MANAGER.getModule("Freecam"))) != null && freecam.isToggled() && !cameraType.isFirstPerson()) {
            ci.cancel();
        }
    }
}

