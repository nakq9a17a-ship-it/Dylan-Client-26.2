/*
 * Decompiled with CFR 0.152.
 */
package dylan.managers;

import java.util.ArrayList;
import dylan.Dylan;
import dylan.events.SubscribeEvent;
import dylan.events.impl.TickEvent;
import dylan.utils.IMinecraft;

public class TaskManager
implements IMinecraft {
    private final ArrayList<Runnable> tasks = new ArrayList();

    public TaskManager() {
        Dylan.EVENT_HANDLER.subscribe(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent event) {
        if (!this.tasks.isEmpty()) {
            this.tasks.getFirst().run();
            this.tasks.removeFirst();
        }
    }

    public void submit(Runnable runnable) {
        this.tasks.add(runnable);
    }
}

