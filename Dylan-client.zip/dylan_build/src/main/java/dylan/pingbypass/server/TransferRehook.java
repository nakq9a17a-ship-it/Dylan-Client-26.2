/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.Minecraft
 *  net.minecraft.core.RegistryAccess
 *  net.minecraft.network.Connection
 *  net.minecraft.network.PacketListener
 *  net.minecraft.network.RegistryFriendlyByteBuf
 *  net.minecraft.network.protocol.game.GameProtocols
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package dylan.pingbypass.server;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.game.GameProtocols;
import dylan.Dylan;
import dylan.events.SubscribeEvent;
import dylan.events.impl.PlayerUpdateEvent;
import dylan.pingbypass.PingBypassFlags;
import dylan.pingbypass.handler.PbPlayHandler;
import dylan.pingbypass.server.S2CForwarder;
import dylan.pingbypass.server.WorldStateReplay;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TransferRehook {
    private static final Logger LOGGER = LoggerFactory.getLogger(TransferRehook.class);

    public TransferRehook() {
        Dylan.EVENT_HANDLER.subscribe(this);
    }

    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        Connection tracked;
        if (Dylan.PINGBYPASS_CONFIG == null || !Dylan.PINGBYPASS_CONFIG.isServer()) {
            return;
        }
        if (!PingBypassFlags.proxyForwardingActive) {
            return;
        }
        if (Dylan.PROXY_SERVER == null) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() == null || mc.player == null || mc.level == null) {
            return;
        }
        Connection current = mc.getConnection().getConnection();
        if (current == (tracked = Dylan.PROXY_SERVER.getServerConnection()) || !current.isConnected()) {
            return;
        }
        LOGGER.warn("[PB] Proxy's own server connection changed underneath us (transfer/backend switch) -- rewiring {} connected client(s)", (Object)Dylan.PROXY_SERVER.getConnections().size());
        Dylan.PROXY_SERVER.setServerConnection(current);
        RegistryAccess registry = mc.level.registryAccess();
        for (Connection clientConnection : Dylan.PROXY_SERVER.getConnections()) {
            PacketListener packetListener;
            if (!clientConnection.isConnected() || !((packetListener = clientConnection.getPacketListener()) instanceof PbPlayHandler)) continue;
            PbPlayHandler oldHandler = (PbPlayHandler)packetListener;
            GameProfile profile = oldHandler.getProfile();
            try {
                clientConnection.setupOutboundProtocol(GameProtocols.CLIENTBOUND_TEMPLATE.bind(RegistryFriendlyByteBuf.decorator((RegistryAccess)registry)));
                S2CForwarder s2cForwarder = new S2CForwarder(clientConnection);
                s2cForwarder.start();
                int initialTeleportId = WorldStateReplay.replay(clientConnection, registry);
                PbPlayHandler newHandler = new PbPlayHandler(Dylan.PROXY_SERVER, clientConnection, profile, s2cForwarder, initialTeleportId);
                clientConnection.setupInboundProtocol(GameProtocols.SERVERBOUND_TEMPLATE.bind(RegistryFriendlyByteBuf.decorator((RegistryAccess)registry), () -> false), (PacketListener)newHandler);
                LOGGER.info("[PB] Rewired {} onto the new server connection after transfer", (Object)profile.name());
            }
            catch (Exception e) {
                LOGGER.error("[PB] Failed to rewire {} after transfer", (Object)profile.name(), (Object)e);
            }
        }
    }
}

