/*
 * Decompiled with CFR 0.152.
 */
package dylan.pingbypass;

import dylan.Dylan;

public class PingBypassFlags {
    public static volatile boolean tolerateRegistryErrors = false;
    public static volatile boolean suppressEncoderErrors = false;
    public static volatile boolean suppressAllDisconnects = false;
    public static volatile boolean proxyForwardingActive = false;
    public static volatile boolean clientOnGround = true;
    public static volatile boolean clientHorizontalCollision = false;

    public static boolean isPingBypassActive() {
        return proxyForwardingActive && Dylan.PINGBYPASS_CONFIG != null && !Dylan.PINGBYPASS_CONFIG.isServer();
    }
}

