/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.Connection
 */
package dylan.pingbypass.protocol;

import net.minecraft.network.Connection;
import dylan.pingbypass.protocol.PbPacket;

@FunctionalInterface
public interface PbPacketHandler<T extends PbPacket> {
    public void handle(T var1, Connection var2);
}

