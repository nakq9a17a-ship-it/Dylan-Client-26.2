/*
 * Decompiled with CFR 0.152.
 */
package dylan;

public final class BuildConstants {
    public static final String MOD_NAME = "Dylan";
    public static final String MOD_ID = "dylan";
    public static final String MOD_VERSION = "v26";
    public static final String MINECRAFT_VERSION = "26.2";
    public static final String GIT_HASH = "eeeb439b78";
    public static final String GIT_REVISION = "436";
    public static final String BUILD_DATE = "2026-09-17";

    private BuildConstants() {
    }
}

