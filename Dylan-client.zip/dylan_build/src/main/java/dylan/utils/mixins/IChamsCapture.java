/*
 * Decompiled with CFR 0.152.
 */
package dylan.utils.mixins;

import dylan.utils.graphics.Glint;

public interface IChamsCapture {
    public boolean dylan$chamsFill();

    public int dylan$chamsFillColor();

    public boolean dylan$chamsOutline();

    public int dylan$chamsOutlineColor();

    public boolean dylan$chamsShine();

    public boolean dylan$chamsGlint();

    public int dylan$chamsGlintColor();

    public Glint.GlintParams dylan$chamsGlintParams();

    public boolean dylan$chamsSuppressReal();

    public float dylan$chamsRealAlpha();

    public void dylan$setChamsRealAlpha(float var1);

    public float dylan$chamsYOffset();

    public void dylan$setChamsYOffset(float var1);

    public void dylan$setChams(boolean var1, int var2, boolean var3, int var4, boolean var5);

    public void dylan$setChams(boolean var1, int var2, boolean var3, int var4, boolean var5, boolean var6);

    public void dylan$setChamsGlint(boolean var1, int var2);

    public void dylan$setChamsGlint(boolean var1, int var2, Glint.GlintParams var3);
}

