/*
 * Decompiled with CFR 0.152.
 */
package dylan.utils.mixins;

public interface IChatHudLineVisible {
    public boolean dylan$isClientMessage();

    public void dylan$setClientMessage(boolean var1);

    public String dylan$getClientIdentifier();

    public void dylan$setClientIdentifier(String var1);
}

