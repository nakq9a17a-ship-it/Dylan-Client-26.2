/*
 * Decompiled with CFR 0.152.
 */
package dylan.utils.mixins;

public interface ISelfState {
    public boolean dylan$isSelf();

    public void dylan$setSelf(boolean var1);
}

