/*
 * Decompiled with CFR 0.152.
 */
package dylan.utils.mixins;

public final class HandsRenderState {
    public static boolean renderingHands = false;

    private HandsRenderState() {
    }
}

