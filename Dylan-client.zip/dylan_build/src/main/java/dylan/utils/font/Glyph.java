/*
 * Decompiled with CFR 0.152.
 */
package dylan.utils.font;

import dylan.utils.font.GlyphMap;

public record Glyph(GlyphMap parent, int u, int v, int width, int height, char value) {
}

