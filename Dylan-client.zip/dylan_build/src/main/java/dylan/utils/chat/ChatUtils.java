/*
 * Decompiled with CFR 0.152.
 */
package dylan.utils.chat;

import dylan.Dylan;
import dylan.modules.impl.core.CommandsModule;
import dylan.utils.text.FormattingUtils;

public class ChatUtils {
    public static Object getPrimary() {
        return FormattingUtils.getFormatting(Dylan.MODULE_MANAGER.getModule(CommandsModule.class).primaryMessageColor.getValue());
    }

    public static Object getSecondary() {
        return FormattingUtils.getFormatting(Dylan.MODULE_MANAGER.getModule(CommandsModule.class).secondaryMessageColor.getValue());
    }
}

