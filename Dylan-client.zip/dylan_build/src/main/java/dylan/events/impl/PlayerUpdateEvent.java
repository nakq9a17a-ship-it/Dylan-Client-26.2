/*
 * Decompiled with CFR 0.152.
 */
package dylan.events.impl;

import dylan.events.Event;

public class PlayerUpdateEvent
extends Event {

    public static class Post
    extends Event {
    }

    public static class Peri
    extends Event {
    }
}

