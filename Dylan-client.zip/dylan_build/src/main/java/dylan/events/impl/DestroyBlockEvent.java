/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.minecraft.core.BlockPos
 */
package dylan.events.impl;

import lombok.Generated;
import net.minecraft.core.BlockPos;
import dylan.events.Event;

public class DestroyBlockEvent
extends Event {
    private final BlockPos position;

    @Generated
    public DestroyBlockEvent(BlockPos position) {
        this.position = position;
    }

    @Generated
    public BlockPos getPosition() {
        return this.position;
    }
}

