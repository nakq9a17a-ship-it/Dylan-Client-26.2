/*
 * Decompiled with CFR 0.152.
 */
package dylan.events.impl;

import dylan.events.Event;

public class PlayerJumpEvent
extends Event {

    public static class Post
    extends Event {
    }
}

