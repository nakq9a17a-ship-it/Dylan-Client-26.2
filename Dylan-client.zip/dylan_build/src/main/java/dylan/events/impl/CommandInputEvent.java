/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package dylan.events.impl;

import lombok.Generated;
import dylan.events.Event;

public class CommandInputEvent
extends Event {
    private final String message;

    @Generated
    public String getMessage() {
        return this.message;
    }

    @Generated
    public CommandInputEvent(String message) {
        this.message = message;
    }
}

